package ordermanager

import (
	"Driver-go/elevio"
	"fmt"

	def "github.com/KralHa0/TTK4145_16/Project/Definitions"
	nw "github.com/KralHa0/TTK4145_16/Project/NetworkHandler"
)

// --------------------------------------------------
// Print helpers
// --------------------------------------------------

func orderStateStr(s def.OrderState) string {
	switch s {
	case def.NoCall:
		return "N"
	case def.Exist:
		return "E"
	case def.Acknowledged:
		return "A"
	case def.Complete:
		return "C"
	default:
		return "?"
	}
}

// PrintNode prints a single node's ID, elevator state, and cab requests.
func PrintNode(node def.Node) {
	stateStr := []string{"Moving", "Idle", "DoorOpen"}
	state := "?"
	if int(node.Elevator.ElevState) < len(stateStr) {
		state = stateStr[node.Elevator.ElevState]
	}
	fmt.Printf("Node %-20s floor=%-2d dir=%-5v state=%-8s malfunction=%v\n",
		node.ID, node.Elevator.CurrentFloor, node.Elevator.Direction, state, node.Elevator.Malfunctioned)
	fmt.Printf("  CabRequests: ")
	for f := 0; f < def.NumFloors; f++ {
		fmt.Printf("[%d:%s]", f, orderStateStr(node.CabRequests[f]))
	}
	fmt.Println()
}

// PrintHallCalls prints the hall requests table (floor, Up, Down).
func PrintHallCalls(hallRequests [def.NumFloors][2]def.OrderState) {
	fmt.Printf("%-6s  %-4s  %-4s\n", "Floor", "Up", "Down")
	for f := 0; f < def.NumFloors; f++ {
		fmt.Printf("%-6d  %-4s  %-4s\n", f,
			orderStateStr(hallRequests[f][def.DirUp]),
			orderStateStr(hallRequests[f][def.DirDown]))
	}
}

// PrintWv prints the full worldview as a table: hall calls (Up/Down) as the
// first column group, followed by one column per node (cab request per floor).
// An elevator-status row is printed below the header.
func PrintWv(wv def.Worldview) {
	const colW = 16
	dirStr := map[int]string{-1: "Dn", 0: "--", 1: "Up"}
	stateStr := []string{"Mov", "Idle", "Door"}
	fmt.Println()

	// Header: node IDs
	fmt.Printf("%-6s  %-4s  %-4s", "Floor", "Up", "Dn")
	for _, node := range wv.Nodes {
		id := string(node.ID)
		if len(id) > colW {
			id = id[:colW]
		}
		fmt.Printf("  %-*s", colW, id)
	}
	fmt.Println()

	// Elevator status row
	fmt.Printf("%-6s  %-4s  %-4s", "", "", "")
	for _, node := range wv.Nodes {
		alivelist := nw.GetAliveList()
		f := "D"
		if alivelist.Peers[node.ID] == true {
			f = "A"
		}
		e := node.Elevator
		dir := dirStr[int(e.Direction)]
		state := "?"
		if int(e.ElevState) < len(stateStr) {
			state = stateStr[e.ElevState]
		}
		malf := "OK"
		if e.Malfunctioned {
			malf = "MF"
		}
		info := fmt.Sprintf("%s%d %s %s %s", f, e.CurrentFloor, dir, state, malf)
		fmt.Printf("  %-*s", colW, info)
	}
	fmt.Println()

	// Separator
	sepLen := 18 + len(wv.Nodes)*(colW+2)
	for i := 0; i < sepLen; i++ {
		fmt.Print("-")
	}
	fmt.Println()

	// One row per floor
	for f := 0; f < def.NumFloors; f++ {
		fmt.Printf("%-6d  %-4s  %-4s",
			f,
			orderStateStr(wv.HallRequests[f][def.DirUp]),
			orderStateStr(wv.HallRequests[f][def.DirDown]))
		for _, node := range wv.Nodes {
			fmt.Printf("  %-*s", colW, orderStateStr(node.CabRequests[f]))
		}
		fmt.Println()
	}

}

// printIncomingWv prints a peer worldview as it arrives — comment out to silence.
func printIncomingWv(wv def.Worldview) {
	if len(wv.Nodes) == 0 {
		return
	}
	fmt.Printf("[OM] Incoming WV from %s:\n", wv.Nodes[0].ID)
	PrintWv(wv)
}

// --------------------------------------------------
// Internal helpers
// --------------------------------------------------

func sendToOrderHandler(orderHandlerWvCh chan<- def.Worldview) {
	select {
	case orderHandlerWvCh <- deepCopyWorldview(localWv):
		//fmt.Println("[OM] Sending to ORA")
	default:
	}
}

func sendToFsm(omToFsmWvCh chan<- def.Worldview) {
	select {
	case omToFsmWvCh <- deepCopyWorldview(localWv):
		//fmt.Println("Sending to FSM")
	default:
	}
}

func deepCopyWorldview(src def.Worldview) def.Worldview {
	copyWv := src
	nodesCopy := make([]def.Node, len(src.Nodes))
	copy(nodesCopy, src.Nodes)
	copyWv.Nodes = nodesCopy
	return copyWv
}

// --------------------------------------------------
// New order from FSM
// --------------------------------------------------

func applyNewOrder(msg elevio.ButtonEvent, aliveList def.AliveList) bool {
	reachedAck := false
	if msg.Button == elevio.BT_Cab {
		// Cab calls: set Exist, then advance to Acknowledged once all alive peers confirm
		cur := localNode().CabRequests[msg.Floor]
		if validTransition(cur, def.Exist) {
			localNode().CabRequests[msg.Floor] = def.Exist
			cabCallKnown[msg.Floor] = true
		}
		if localNode().CabRequests[msg.Floor] == def.Exist {
			if allAliveCabAtOrAbove(msg.Floor, def.Exist, aliveList) {
				if validTransition(localNode().CabRequests[msg.Floor], def.Acknowledged) {
					localNode().CabRequests[msg.Floor] = def.Acknowledged
					reachedAck = true
				}
			}
		}
	} else {
		var dir def.DirectionUpDown
		switch msg.Button {
		case elevio.BT_HallUp:
			dir = def.DirUp
		case elevio.BT_HallDown:
			dir = def.DirDown
		}
		cur := localWv.HallRequests[msg.Floor][dir]
		if validTransition(cur, def.Exist) {
			localWv.HallRequests[msg.Floor][dir] = def.Exist
		}
		// Advance to Acknowledged immediately if all alive peers already have Exist
		if localWv.HallRequests[msg.Floor][dir] == def.Exist {
			if allAliveHallAtOrAbove(msg.Floor, int(dir), def.Exist, aliveList) {
				if validTransition(localWv.HallRequests[msg.Floor][dir], def.Acknowledged) {
					localWv.HallRequests[msg.Floor][dir] = def.Acknowledged
					reachedAck = true
				}
			}
		}
	}
	return reachedAck
}

// --------------------------------------------------
// Completion from FSM
// --------------------------------------------------

func applyCompletion(floor int, dir def.DirectionUpDown, aliveList def.AliveList) {
	// Hall: FSM completion is authoritative — always advance to Complete.
	// Consensus (Complete→NoCall) is handled separately in applyHallConsensus.
	cur := localWv.HallRequests[floor][dir]
	if validTransition(cur, def.Complete) {
		localWv.HallRequests[floor][dir] = def.Complete
	}

	// Cab: advance to Complete; NoCall via peer consensus in applyHallConsensus.
	cabCur := localNode().CabRequests[floor]
	if validTransition(cabCur, def.Complete) {
		localNode().CabRequests[floor] = def.Complete
		cabCallKnown[floor] = true
	}
}
